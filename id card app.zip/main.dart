import 'package:and_trial_app/User.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return _MyAppState();
  }

}
class _MyAppState extends State<MyApp>{
  int _counter=0;
  List<User> users = [];
  User u=User('ajay','manager','ajay@gmail.com',0);
  _MyAppState(){
    users.add(u);
    users.add(User('abc','admin','aaa@gmail.com',0));
    users.add(User('bbb','trainer','bbb@gmail.com',0));
  }
  void _incrementCounter(){
    setState(() {
      _counter+=1;
    });
  }

  Widget _displayName(){

    var map = users.map((userItem)=>{
       userItem.userName
    });
    return
     Text(map.toList().elementAt(0).toString(),
          style: TextStyle(
            color:  Colors.amber,
            fontSize: 28.0,
            letterSpacing: 2.0,
            fontWeight: FontWeight.bold,
          )
      );
  }
// This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',

      home: Scaffold(
        backgroundColor: Colors.grey[900],
        appBar: AppBar(
          title: Text("android app 1"),
          centerTitle: true,
          backgroundColor: Colors.grey[850],
          elevation: 1.0,
        ),
        body:
        Padding(
          padding: const EdgeInsets.fromLTRB(30.0,40.0,30.0,0.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
                Center(
                  child: CircleAvatar(
                    backgroundImage: NetworkImage("https://w7.pngwing.com/pngs/954/328/png-transparent-computer-icons-user-profile-avatar-heroes-head-recruiter-thumbnail.png"),
                    radius: 40.0,

                  )
                ),
              Divider(
                height: 40.0,
                thickness: 4.0,
                color: Colors.grey[800],
                indent: 80,
                endIndent: 80,
              ),
              Text('NAME', style:
              TextStyle(
                color:  Colors.grey,
                letterSpacing: 2.0,
              )),
              SizedBox(height: 10.0),
             _displayName(),
              SizedBox(height: 40.0),
              Text('DESIGNATION', style:
              TextStyle(
                color:  Colors.grey,
                letterSpacing: 2.0,
              )),
              SizedBox(height: 10.0),
              Text('Senior Trainer',
                  style: TextStyle(
                    color:  Colors.amber,
                    fontSize: 28.0,
                    letterSpacing: 2.0,
                    fontWeight: FontWeight.bold,
                  )
              ),
              SizedBox(height: 40.0),
              Row(
                children: <Widget>[
                  Icon(
                    Icons.email,
                    color: Colors.grey[400],
                  ),
                  SizedBox(width: 10.0),
                  Text('kathiresan@cp.com',style:
                  TextStyle(
                    color:  Colors.amber,
                    fontSize: 18.0,
                    letterSpacing: 1.0,
                  )),
                ],
              ),
              SizedBox.fromSize(size: Size.fromHeight(20.0),),
              Center(
                child: Text('Like the profile!!! click here', style: TextStyle(
                  color:Colors.white54
                )),
              ),
              SizedBox.fromSize(size: Size.fromHeight(15.0),),
              Row(
                mainAxisAlignment: MainAxisAlignment.center, //centers the icon
                crossAxisAlignment: CrossAxisAlignment.center,//cneters row elements to center of icon here ie 5 is in vertical center of the thumb icon
                children: [
                   IconButton(onPressed: ()=>
                    _incrementCounter() ,highlightColor: Colors.amber, color:Colors.grey,icon: Icon(Icons.thumb_up_off_alt_rounded)),
                Text('$_counter',style:TextStyle(
                    color:Colors.white54
                  )),
                ],

              ),


            ]
          ),
        )
      )
    );
  }
}
