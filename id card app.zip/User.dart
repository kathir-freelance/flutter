
class User{
  String? _userName;
  String? _designation;
  String? _mail;
  int _count=0;
  User(this._userName,this._designation,this._mail,this._count);

  @override
  String toString() {
    return 'User{_userName: $_userName, _designation: $_designation, _mail: $_mail, _count: $_count}';
  }

  int get count => _count;

  String? get mail => _mail;

  String? get designation => _designation;

  String? get userName => _userName;
}