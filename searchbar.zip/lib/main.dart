import 'package:flutter/material.dart';
import 'package:searchbardemo/birds.dart';

void main() {
  runApp(MaterialApp( home: MyApp()));
}

class MyApp extends StatefulWidget {

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  String? name;
  var ctlr=TextEditingController();
  @override
  Widget build(BuildContext context) {
  return Scaffold(appBar: AppBar(title: Text("my app")),
    body: Column(
      children: [
        Container(
          child: TextField(
            controller: ctlr,
            onChanged: (value){
              _search(value);
              setState(() {
                name=ctlr.text;
              });
            },
          ),
        ),
SizedBox(height: 20.0,),
       Expanded(
        child:
        ListView.builder(
             shrinkWrap: true,

              itemCount: allBirds.length,
                itemBuilder: (context,index){

              final d=allBirds[index];
              return ListTile(title: Text("${d.title}"),subtitle: Text("${d.cost}"),);
            })
                )
      ],
    ),
  );
  }

  void _search(String qry) {
    final suggestions=allBirds.where(
            (bird){
      String? title=bird.title!.toLowerCase();
      String? inp=qry.toLowerCase();
      return title.contains(inp);
    }).toList();
    setState(() {
      allBirds=suggestions;
    });
  }
}
