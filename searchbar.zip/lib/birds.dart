class Birds{
  final String? title;
  final int? cost;

  Birds({required this.title, required this.cost});


}
List<Birds> allBirds=[
   Birds(title: "cockteil", cost: 3000),
  Birds(title: "lutino", cost: 5000),
  Birds(title: "cockteil2", cost: 4000),
];