import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  // This widget is the root of your application.
  var flag =true;
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home:Scaffold(
        appBar: AppBar(title: Text("cross fade"),),
        body:Center(
          child: Column(
            children: <Widget>[
              AnimatedCrossFade(
                firstCurve: Curves.elasticIn,
                  secondCurve: Curves.easeInCubic,
                  firstChild: Login(),
                  secondChild: SignUp(),
                  crossFadeState:
                  flag ? CrossFadeState.showFirst : CrossFadeState.showSecond,
                  duration: Duration(milliseconds: 500)),
              ElevatedButton(
                child: Text(flag?'login':'register'),
                onPressed: () {
                  flag?validateLogin():saveUser();
                },
              ),
              TextButton(
                child: Text(flag ? 'Go to Sign Up' : 'Go to Login'),
                onPressed: () {
                  setState(() {
                    flag = !flag;
                  });
                },
              )
            ],
          ),
        ),

      )
    );
  }

  validateLogin() {
    print('validated...logeed in');
  }

  saveUser() {
    print('saved user');
  }
}

class Login extends StatelessWidget {
  const Login({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(20.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
          Padding(
            child: Text(
              'Login',
              style: TextStyle(fontSize: 30),
            ),
            padding: EdgeInsets.only(bottom: 100.0),
          ),
          TextField(
            decoration: InputDecoration(labelText: 'User name'),
          ),
          TextField(
            decoration: InputDecoration(labelText: 'Password'),
          ),
        ],
      ),
    );
  }
}
class SignUp extends StatelessWidget {
  const SignUp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(20.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
          Padding(
            child: Text(
              'Sign Up',
              style: TextStyle(fontSize: 30),
            ), padding: EdgeInsets.only(bottom: 100.0),
          ),
          TextField(
            decoration: InputDecoration(labelText: 'User name'),
          ),
          TextField(
            decoration: InputDecoration(labelText: 'Email'),
          ),
          TextField(
            decoration: InputDecoration(labelText: 'Password'),
          ),
          TextField(
            decoration: InputDecoration(labelText: 'Confirm Password'),
          ),
        ],
      ),
    );
  }
}
