import 'package:flutter/material.dart';
import 'package:provider/src/provider.dart';
import 'package:providercp/CounterProvider.dart';

class profile extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
    int a=0;
    return SafeArea(
      child: Scaffold(body: Container(

        child:
        Column(
          children:[
            Text("clicked $a"),

          ]
)
      ),
          floatingActionButton: FloatingActionButton(
            child: Icon(Icons.add),
          onPressed: (){

          Provider.of<Counter>(context, listen: false);
          a=context.read<Counter>().count;
          print(a);
      },
      ),
      ),
    );
  }
}
