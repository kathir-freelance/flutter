import 'package:flutter/material.dart';
import 'package:providercp/CounterProvider.dart';
import 'package:provider/provider.dart';
class home extends StatelessWidget {
  const home({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home:Scaffold(
          appBar: AppBar(),
          body: Column(
            children: [
              Text("clicked : ${context.watch<Counter>().count}"),
              ElevatedButton(onPressed: (){
                Navigator.pushNamed(context, 'profile');
              }, child:
              Text("Next Screen")
              )
            ],
          ),
        floatingActionButton: FloatingActionButton(
          onPressed: (){
            context.read<Counter>().increment();
          },
          child: Icon(Icons.add),
        ),
        )
    );
  }
}
