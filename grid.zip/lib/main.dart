import 'package:flutter/material.dart';

void main() {
  runApp( MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("app bar")),
          body: GridView(
//scrollDirection: Axis.horizontal,
           // gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 6,),
            gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 200,mainAxisExtent: 100.0,crossAxisSpacing: 20.0,mainAxisSpacing: 30.0),
            children: [
              Container(height:100.0, width:60.0, color:Colors.yellow,margin: EdgeInsets.all(10.0),),
              Container(color:Colors.blue,margin: EdgeInsets.all(10.0),),
              Container(color:Colors.deepPurple,margin: EdgeInsets.all(10.0),),
              Container(color:Colors.yellow,margin: EdgeInsets.all(10.0),),
              Container(color:Colors.blue,margin: EdgeInsets.all(10.0),),
              Container(color:Colors.deepPurple,margin: EdgeInsets.all(10.0),),
              Container(color:Colors.yellow,margin: EdgeInsets.all(10.0),),
              Container(color:Colors.blue,margin: EdgeInsets.all(10.0),),
              Container(color:Colors.deepPurple,margin: EdgeInsets.all(10.0),), Container(color:Colors.yellow,margin: EdgeInsets.all(10.0),),
              Container(color:Colors.blue,margin: EdgeInsets.all(10.0),),
              Container(color:Colors.deepPurple,margin: EdgeInsets.all(10.0),),

            ],
          )
        ),
      );
  }
}
