import 'package:flutter/material.dart';

class BTab3 extends StatefulWidget {
  @override
  State<BTab3> createState() => _BTab3State();
}

class _BTab3State extends State<BTab3> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

        body:Center(child: Container(child: Text("Btab3"))));
  }
}
