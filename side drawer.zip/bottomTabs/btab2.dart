import 'package:flutter/material.dart';

class BTab2 extends StatefulWidget {
  @override
  State<BTab2> createState() => _BTab2State();
}

class _BTab2State extends State<BTab2> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

        body:Center(child: Container(child: Text("Btab2"))));
  }
}
