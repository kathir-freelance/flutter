import 'package:flutter/material.dart';

class BTab1 extends StatefulWidget {
  @override
  State<BTab1> createState() => _BTab1State();
}

class _BTab1State extends State<BTab1> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

        body:Center(child: Container(child: Text("Btab1"))));
  }
}
