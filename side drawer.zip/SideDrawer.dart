import 'package:flutter/material.dart';

class  SideDrawer extends StatelessWidget {
    @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Drawer(
          child: ListView(
            padding: EdgeInsets.only(left:0.0),
            children: [
              UserAccountsDrawerHeader(
                accountName: Text("kathiresan"),
                accountEmail: Text("kathiresan@gmail.com"),
                otherAccountsPictures: [Icon(Icons.home),Icon(Icons.ac_unit)],
                currentAccountPicture:
                CircleAvatar(
                    backgroundImage: NetworkImage("https://previews.123rf.com/images/valentint/valentint1605/valentint160503223/56415988-my-account-icon-internet-button-on-white-background-.jpg")),
              ),
              // Container(
              //   height: 100.0,
              //
              //   child: const DrawerHeader(
              //
              //     padding: EdgeInsets.only(left:30.0,bottom: 20.0),
              //     decoration: BoxDecoration(
              //         color: Colors.blue,
              //     ),
              //     child: Text('Drawer Header'),
              //   ),
              // ),
              ListTile(
                leading: Icon(Icons.home),
                  title:Text("home"),
                onTap: ()=> Navigator.pushNamed(context, 'home'),
              ),
              ListTile(
                leading: Icon(Icons.video_camera_back),
                title:Text("videos"),
                onTap: ()=> Navigator.pushNamed(context, 'videos'),
              ),
              ListTile(
                leading: Icon(Icons.settings),
                title:Text("settings"),
                onTap: ()=> Navigator.pushNamed(context, 'settings'),
              ),
            ],
          )// Populate the Drawer in the next step.
      ),
    );
  }
}
