import 'package:drwaer_example/bottomTabs/btab1.dart';
import 'package:drwaer_example/bottomTabs/btab2.dart';
import 'package:drwaer_example/bottomTabs/btab3.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class Videos extends StatefulWidget {


  @override
  State<Videos> createState() => _VideosState();
}

class _VideosState extends State<Videos> {
  @override
  void initState() {
      SystemChrome.setEnabledSystemUIOverlays([SystemUiOverlay.top]);
   // SystemChrome.setEnabledSystemUIOverlays([SystemUiOverlay.top]);
    super.initState();
  }

  @override
  void dispose() {
    SystemChrome.setEnabledSystemUIOverlays(
        [SystemUiOverlay.top, SystemUiOverlay.top]);
    super.dispose();
  }
  int _index=0;
  final List<Widget> _tabs=[BTab1(),BTab2(),BTab3()];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: Text("video")),
        body:    _tabs[_index],
      bottomNavigationBar: BottomNavigationBar(
        showSelectedLabels: true,
        showUnselectedLabels: false,
        unselectedItemColor: Colors.deepOrangeAccent,
        currentIndex: _index,
        onTap: (inx)=>setState(() {
          _index=inx;
        }),
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.call),
            label: 'Calls',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.camera),
            label: 'Camera',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat),
            label: 'Chats',
          ),
        ],
      ),
    );
  }
}
