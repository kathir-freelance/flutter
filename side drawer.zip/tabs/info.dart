import 'package:flutter/material.dart';
class info extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Container(

    child: Text("info")

    );
  }
}
