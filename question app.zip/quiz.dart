import 'package:flutter/material.dart';
import 'package:new_app1/questions.dart';

import 'answer.dart';

class Quiz extends StatelessWidget {
  final Function? answerQn;
  final int index;
  final List<Map<String, Object>>? qns;
  Quiz({@required this.answerQn, @required this.qns, @required this.index = 0});

  @override
  Widget build(BuildContext context) {
    return Column(
        // children: [Text("hi"), Text("hello"), Text("to my app")],

        children: [
          Questions(qns![index]['questionText'].toString()),
          ...(qns![index]['answers'] as List<Map<String, Object>>).map((ans) {
            return Answer(() => answerQn!(ans['score']), ans['text']);
          }).toList()
        ]);
  }
}
