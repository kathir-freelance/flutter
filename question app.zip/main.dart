import 'package:flutter/material.dart';
import 'package:new_app1/answer.dart';
import 'package:new_app1/quiz.dart';
import 'package:new_app1/result.dart';
import './questions.dart';

void main() {
  runApp(MyHomePage());
}

class MyHomePage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return MyHomePageState();
  }
}

class MyHomePageState extends State<MyHomePage> {
  var _index = 0;
  var _totScore = 0;
  static final question = [
    {
      'questionText': 'What\'s your favorite color?',
      'answers': [
        {'text': 'Black', 'score': 10},
        {'text': 'Red', 'score': 5},
        {'text': 'Green', 'score': 3},
        {'text': 'White', 'score': 1},
      ],
    },
    {
      'questionText': 'What\'s your favorite animal?',
      'answers': [
        {'text': 'Rabbit', 'score': 3},
        {'text': 'Snake', 'score': 11},
        {'text': 'Elephant', 'score': 5},
        {'text': 'Lion', 'score': 9},
      ],
    },
    {
      'questionText': 'Who\'s your favorite instructor?',
      'answers': [
        {'text': 'M', 'score': 1},
        {'text': 'A', 'score': 1},
        {'text': 'SS', 'score': 1},
        {'text': 'ABS', 'score': 1},
      ],
    },
  ];
  void _answerQn(int score) {
    _totScore += score;
    setState(() {
      _index = _index + 1;
    });

    print("this is my answer  $_index");
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Text("my app"),
        ),
        body: _index < question.length
            ? Quiz(answerQn: _answerQn, index: _index, qns: question)
            : Result(),
      ),
    );
  }
}
