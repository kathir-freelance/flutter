import 'package:cp_quote_app/QuoteCard.dart';
import 'package:cp_quote_app/quote.dart';
import 'package:flutter/material.dart';
import 'package:cp_quote_app/QuoteCard.dart';
void main() {
  runApp( MyApp());
}



class MyApp extends StatelessWidget {
  List<Quote> quotes = [
    Quote(author: 'Oscar Wilde', text: 'Be yourself; everyone else is already taken'),
    Quote(author: 'Oscar', text: 'I have nothing to declare except my genius'),
    Quote(author: 'Wilde', text: 'The truth is rarely pure and never simple')
  ];

  /*
  List<String> quotes = [
    'Be yourself; everyone else is already taken',
    'I have nothing to declare except my genius',
    'The truth is rarely pure and never simple'
  ];
*/

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      home: Scaffold(
        backgroundColor: Colors.grey[800],
        appBar: AppBar(
          title: Text('quotes app'),
          centerTitle: true,

        ),
        body:
        Column(
          children: quotes.map((quote) =>QuoteCard(quote:quote)).toList(),
        ),

        ),
      );
  }
}
