import 'package:flutter/material.dart';
import 'package:pageview_ex/camera.dart';
import 'package:pageview_ex/email.dart';
import 'package:pageview_ex/home.dart';

void main() {
  runApp( MyApp());
}

class MyApp extends StatefulWidget {
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  var _currndex=0;
  var _pages=[home(),camera(),email()];
  var _pageController=PageController();
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {

    return
      MaterialApp(
        home: Scaffold(appBar: AppBar(title: Text("bottom"),),
body: PageView(
  children: _pages,
  onPageChanged: (index) {
    setState(() {
      _currndex = index;
    });
  },
  controller: _pageController,
),
         bottomNavigationBar: BottomNavigationBar(
           currentIndex:_currndex ,
           onTap: (index){
              setState(() {
                _currndex=index;
                _pageController.animateToPage(_currndex,duration: Duration(milliseconds: 2000), curve: Curves.bounceIn);
              });
           },
           items: [
             BottomNavigationBarItem(label: "home" ,icon: Icon(Icons.home)),
             BottomNavigationBarItem(label:"camera", icon: Icon(Icons.camera)),
             BottomNavigationBarItem(label:"email",icon: Icon(Icons.email)),
           ],


         )


    ),
      );
  }
}
